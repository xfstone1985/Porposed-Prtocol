package com.xfstone.bean;

import com.xfstone.util.StringOperation;

public class ReaderAndServer {
    private String ID;
    private String keyold;
    private String keynew;
    private String IDSold;
    private String IDSnew;
    private String n1;
    private String n2;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getIDSold() {
        return IDSold;
    }

    public void setIDSold(String IDSold) {
        this.IDSold = IDSold;
    }

    public String getIDSnew() {
        return IDSnew;
    }

    public void setIDSnew(String IDSnew) {
        this.IDSnew = IDSnew;
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }


    public String computerA(String IDS, String k, String n1) {
        String t = StringOperation.getRef(IDS, k);
        String A = StringOperation.binaryStringXOR(t, n1);
        return A;
    }

    public String computerB(String IDS, String n1, String n2) {
        String t = StringOperation.binaryStringXOR(IDS, n1);
        String B = StringOperation.binaryStringXOR(t, n2);
        return B;
    }

    public String computerC(String n1, String n2) {
        String t1 = StringOperation.getRef(n1, this.getID());
        String t2 = StringOperation.getRef(n2, this.getID());
        String C = StringOperation.getRef(t1, t2);
        return C;
    }

    public String updateIDS(String n1, String n2) {
        String t1 = StringOperation.binaryStringXOR(this.getIDSold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getKeyold(), n2);
        String t3 = StringOperation.getRotLeft(t1, t2);
        String t4 = StringOperation.binaryStringXOR(n1, n2);
        String IDSnew = StringOperation.getRef(t3, t4);
        return IDSnew;

    }

    public String updateKey(String n1, String n2) {
        String t1 = StringOperation.getRotRight(this.getKeyold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getIDSold(), n2);
        String Keynew = StringOperation.getRef(t1, t2);
        return Keynew;
    }

    public boolean checkD(String n1, String n2, String D) {
        boolean flag = false;
        String IDSnew = this.updateIDS(n1, n2);
        String Keynew = this.updateKey(n1, n2);
        System.out.print("IDSnew:");
        System.out.println(IDSnew);
        System.out.print("Keynew:");
        System.out.println(Keynew);
        String t1 = StringOperation.getRotLeft(IDSnew, Keynew);
        String t2 = StringOperation.binaryStringXOR(n1, n2);
        String t3 = StringOperation.getRef(t1, t2);
        String t4 = StringOperation.getRotRight(t3, n2);
        String D1 = StringOperation.binaryStringXOR(t4, this.getID());
        System.out.print("reader computers D:");
        System.out.println(D1);
        if (D.equals(D1)) {
            flag = true;
            this.setIDSnew(IDSnew);
            this.setKeynew(Keynew);
        }

        return flag;
    }

    public String computerE() {
        return StringOperation.getRef(this.getKeynew(),this.getID());
    }
}
