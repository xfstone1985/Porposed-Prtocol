package com.xfstone.test;

import com.xfstone.util.StringOperation;
import org.junit.Test;

import static org.junit.Assert.*;

public class StringOperationTest {

    @Test
    public void getRef() {
        String n1=StringOperation.generateRandomBinaryString(8);
        String n2=StringOperation.generateRandomBinaryString(8);
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(StringOperation.getRef(n1,n2));
        System.out.println(StringOperation.getRef(n2,n1));
    }
}