package com.xfstone.execution;

import com.xfstone.bean.ReaderAndServer;
import com.xfstone.bean.Tag;
import com.xfstone.util.StringOperation;

public class ProposedProtocol {
    public static void main(String[] args) {
    /*
    Initialization of tag and reader
     */
    int BitLength = 96;
    int N=100;
    long startTime = System.nanoTime();
    Runtime runtime = Runtime.getRuntime();
    // total memory
    long totalMemory = runtime.totalMemory();
    for(int i=0;i<N;i++){
        Tag tag = new Tag();
        String idsold = StringOperation.generateRandomBinaryString(BitLength);
        String keyold = StringOperation.generateRandomBinaryString(BitLength);
        String id = StringOperation.generateRandomBinaryString(BitLength);
        tag.setIDSold(idsold);
        tag.setKeyold(keyold);
        tag.setID(id);
        ReaderAndServer readerAndServer = new ReaderAndServer();
        readerAndServer.setIDSold(idsold);
        readerAndServer.setKeyold(keyold);
        readerAndServer.setID(id);
        System.out.println("-----initial stage begins-----");
        System.out.println("tag's ID:"+tag.getID());
        System.out.println("tag's current IDS:"+tag.getIDSold());
        System.out.println("tag's current Key"+tag.getKeyold());
        System.out.println("-----initial stage ends-----");
    /*
    The first step and the second step of the protocol are omitted, and the third step has reader to generate A, B, and C
     */

        System.out.println("-----protocol begins to execute-----");
        System.out.println("-----step1:reader sends 'Hello' to tag-----");
        System.out.println("-----step2:tag sends IDS to reader-----");
        System.out.println("-----step3 begins:reader receives the IDS and starts to computer A B and C-----");
        readerAndServer.setN1(StringOperation.generateRandomBinaryString(BitLength));
        readerAndServer.setN2(StringOperation.generateRandomBinaryString(BitLength));
        String A = readerAndServer.computerA(readerAndServer.getIDSold(), readerAndServer.getKeyold(), readerAndServer.getN1());
        String B = readerAndServer.computerB(readerAndServer.getIDSold(), readerAndServer.getN1(), readerAndServer.getN2());
        String C = readerAndServer.computerC(readerAndServer.getN1(), readerAndServer.getN2());
        System.out.print("random n1:");
        System.out.println(readerAndServer.getN1());
        System.out.print("random n2:");
        System.out.println(readerAndServer.getN2());
        System.out.print("reader computers A:");
        System.out.println(A);
        System.out.print("reader computers B:");
        System.out.println(B);
        System.out.print("reader computers C:");
        System.out.println(C);
        System.out.println("A B and C is sent to tag");
        System.out.println("-----step3 ends-----");
        System.out.println();
        System.out.println("-----step4 begins: tag vertifies A B C and computers D-----");
        if(!tag.checkC(A,B,C))

        {
            System.out.println("-----reader vertification failed at step 4,protocol aborts-----");
            long endTime = System.nanoTime();
            long duration = (endTime - startTime) / 1000;
            System.out.println("the time for protocol execution is\u0020" + duration + "\u0020milliseconds");
            System.exit(1);
        }
        System.out.println("C is checked,tag is authenticated! IDS and key will be updated");
        String D = tag.computerD(tag.getN1(), tag.getN2());
        System.out.print("tag computers D:");
        System.out.println(D);
        System.out.println("-----step4 ends,and D is sent to reader-----");
        System.out.println();
        System.out.println("-----step5 begins, reader starts to check D-----");
        if(!readerAndServer.checkD(readerAndServer.getN1(),readerAndServer.getN2(),D))

        {
            System.out.println("-----tag vertification failed at step 5,protocol aborts-----");
            long endTime = System.nanoTime();
            long duration = (endTime - startTime) / 1000;
            System.out.println("the time for protocol execution is\u0020" + duration + "\u0020milliseconds");
            System.exit(1);
        } else
            System.out.println("----D is checked,reader is authenticated! step5 ends----");
        System.out.print("reader and server update tag's new IDS:");
        System.out.println(readerAndServer.getIDSnew());
        System.out.print("reader and server update tag's new key:");
        System.out.println(readerAndServer.getKeynew());
        System.out.println();
        System.out.println("---setp6 begins,reader computes E and sent it to tag");
        String E=readerAndServer.computerE();
        System.out.print("reader computers E:");
        System.out.println(E);
        if(!tag.checkE(E)){
            System.out.println("-----E is not vertified, protocol aborts,tag won't update IDS and Key-----");
            long endTime = System.nanoTime();
            long duration = (endTime - startTime) / 1000;
            System.out.println("the time for protocol execution is\u0020" + duration + "\u0020milliseconds");
            System.exit(1);
        }else
            System.out.println("E is checked,tag will update IDS and Key");
        System.out.print("tag's new IDS:");
        System.out.println(tag.getIDSnew());
        System.out.print("tag's new key:");
        System.out.println(tag.getKeynew());
        System.out.println("-----step6 ends,the protocol is successfully executed!-----");

    }
        long endTime = System.nanoTime();
        long duration = (endTime - startTime) / 1000;
        System.out.println("the time for protocol execution is\u0020"+duration +"\u0020milliseconds");
        long freeMemory = runtime.freeMemory();
        double usedMemory = (totalMemory - freeMemory) / Math.pow(1024, 2);
        System.out.print("the used memory for protocol execution is : ");
        System.out.printf("%.5f MB",usedMemory);

}
}