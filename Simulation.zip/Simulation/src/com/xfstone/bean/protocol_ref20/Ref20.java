package com.xfstone.bean.protocol_ref20;

import java.util.Random;

public class Ref20 {
    public static String protocolExecution(int taskId, int bitLength){
        StringBuilder sb=new StringBuilder();
        sb.append("-----initial stage begins-----"+"\n");
        Tag tag = new Tag();
        String idsold = StringOperation.generateRandomBinaryString(bitLength);
        String keyold = StringOperation.generateRandomBinaryString(bitLength);
        String id = StringOperation.generateRandomBinaryString(bitLength);
        tag.setIDSold(idsold);
        tag.setKeyold(keyold);
        tag.setID(id);
        ReaderAndServer readerAndServer = new ReaderAndServer();
        readerAndServer.setIDSold(idsold);
        readerAndServer.setKeyold(keyold);
        readerAndServer.setID(id);
        sb.append("-----initial stage ends-----"+"\n");
        sb.append("-----protocol begins to execute-----"+"\n");
//        sb.append("-----step1:reader sends 'Hello' to tag-----");
//        sb.append("-----step2:tag sends IDS to reader-----");
//        sb.append("-----step3 begins:reader receives the IDS and starts to computer A B and C-----");
        readerAndServer.setN1(StringOperation.generateRandomBinaryString(bitLength));
        readerAndServer.setN2(StringOperation.generateRandomBinaryString(bitLength));
        String A = readerAndServer.computerA(readerAndServer.getIDSold(), readerAndServer.getKeyold(), readerAndServer.getN1());
        String B = readerAndServer.computerB(readerAndServer.getIDSold(), readerAndServer.getN1(), readerAndServer.getN2());
        String C = readerAndServer.computerC(readerAndServer.getN1(), readerAndServer.getN2());
        //System.out.print("random n1:");
        //System.out.println(readerAndServer.getN1());
        //System.out.print("random n2:");
        //System.out.println(readerAndServer.getN2());
        //System.out.print("reader computers A:");
        //System.out.println(A);
        //System.out.print("reader computers B:");
        //System.out.println(B);
        //System.out.print("reader computers C:");
        //System.out.println(C);
        //System.out.println("A B and C is sent to tag");
        //System.out.println("-----step3 ends-----");
        //System.out.println();
        //System.out.println("-----step4 begins: tag vertifies A B C and computers D-----");
        if (!tag.checkC(A, B, C)) {
            System.out.println("-----reader vertification failed at step 4,protocol aborts-----"+"\n");
        }
        //System.out.println("C is checked,tag is authenticated! IDS and key will be updated");
        String D = tag.computerD(tag.getN1(), tag.getN2());
//        System.out.print("tag's new IDS:");
//        System.out.println(tag.getIDSnew());
//        System.out.print("tag's new key:");
//        System.out.println(tag.getKeynew());
//        System.out.print("tag computers D:");
//        System.out.println(D);
//        System.out.println("-----step4 ends,and D is sent to reader-----");
//        System.out.println();
//        System.out.println("-----step5 begins, reader starts to check D-----");
        if (!readerAndServer.checkD(readerAndServer.getN1(), readerAndServer.getN2(), D)) {
            System.out.println("-----tag vertification failed at step 5,protocol aborts-----"+"\n");
        } else {
//            System.out.println("D is checked,reader is authenticated!");
//            System.out.print("reader and server update tag's new IDS:");
//            System.out.println(readerAndServer.getIDSnew());
//            System.out.print("reader and server update tag's new key:");
//            System.out.println(readerAndServer.getKeynew());
//            System.out.println("-----step5 ends,the protocol is successfully executed!-----");
        }
        String result="tag["+taskId+"]"+sb;
        return result;
    }
}

class ReaderAndServer {
    private String ID;
    private String keyold;
    private String keynew;
    private String IDSold;
    private String IDSnew;
    private String n1;
    private String n2;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getIDSold() {
        return IDSold;
    }

    public void setIDSold(String IDSold) {
        this.IDSold = IDSold;
    }

    public String getIDSnew() {
        return IDSnew;
    }

    public void setIDSnew(String IDSnew) {
        this.IDSnew = IDSnew;
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }


    public String computerA(String IDS, String k, String n1) {
        String t = StringOperation.getRef(IDS, k);
        String A = StringOperation.binaryStringXOR(t, n1);
        return A;
    }

    public String computerB(String IDS, String n1, String n2) {
        String t = StringOperation.binaryStringXOR(IDS, n1);
        String B = StringOperation.binaryStringXOR(t, n2);
        return B;
    }

    public String computerC(String n1, String n2) {
        String t1 = StringOperation.getRef(n1, n1);
        String t2 = StringOperation.getRef(n2, n2);
        String C = StringOperation.getRef(t1, t2);
        return C;
    }

    public String updateIDS(String n1, String n2) {
        String t1 = StringOperation.binaryStringXOR(this.getIDSold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getKeyold(), n2);
        String t3 = StringOperation.getRotLeft(t1, t2);
        String t4 = StringOperation.binaryStringXOR(n1, n2);
        String IDSnew = StringOperation.getRef(t3, t4);
        return IDSnew;

    }

    public String updateKey(String n1, String n2) {
        String t1 = StringOperation.getRotRight(this.getKeyold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getIDSold(), n2);
        String Keynew = StringOperation.getRef(t1, t2);
        return Keynew;
    }

    public boolean checkD(String n1, String n2, String D) {
        boolean flag = false;
        String IDSnew = this.updateIDS(n1, n2);
        String Keynew = this.updateKey(n1, n2);
        System.out.print("IDSnew:");
        System.out.println(IDSnew);
        System.out.print("Keynew:");
        System.out.println(Keynew);
        String t1 = StringOperation.getRotLeft(IDSnew, Keynew);
        String t2 = StringOperation.binaryStringXOR(n1, n2);
        String t3 = StringOperation.getRef(t1, t2);
        String t4 = StringOperation.getRotRight(t3, n2);
        String D1 = StringOperation.binaryStringXOR(t4, this.getID());
        System.out.print("reader computers D:");
        System.out.println(D1);
        if (D.equals(D1)) {
            flag = true;
            this.setIDSnew(IDSnew);
            this.setKeynew(Keynew);
        }

        return flag;
    }

}
class Tag {
    private String ID;
    private String keyold;
    private String keynew;
    private String IDSold;
    private String IDSnew;

    private String n1;

    private String n2;

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getIDSold() {
        return IDSold;
    }

    public void setIDSold(String IDSold) {
        this.IDSold = IDSold;
    }

    public String getIDSnew() {
        return IDSnew;
    }

    public void setIDSnew(String IDSnew) {
        this.IDSnew = IDSnew;
    }

    public boolean checkC(String A, String B, String C) {
        boolean flag = false;
        String n1 = StringOperation.binaryStringXOR(A, StringOperation.getRef(this.getIDSold(), this.getKeyold()));
        String n2 = StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(B, n1), this.getIDSold());
        System.out.print("tag computers n1:");
        System.out.println(n1);
        System.out.print("tag computers n2:");
        System.out.println(n2);
        String C1 = StringOperation.getRef(StringOperation.getRef(n1, n1), StringOperation.getRef(n2, n2));
        System.out.print("tag computers C:");
        System.out.println(C1);
        if (C1.equals(C)) {
            flag = true;
            this.setN1(n1);
            this.setN2(n2);
        }
        return flag;
    }

    public String updateIDS(String n1, String n2) {
        String t1 = StringOperation.binaryStringXOR(this.getIDSold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getKeyold(), n2);
        String t3 = StringOperation.getRotLeft(t1, t2);
        String t4 = StringOperation.binaryStringXOR(n1, n2);
        String IDS = StringOperation.getRef(t3, t4);
        return IDS;

    }

    public String updateKey(String n1, String n2) {
        String t1 = StringOperation.getRotRight(this.getKeyold(), n1);
        String t2 = StringOperation.binaryStringXOR(this.getIDSold(), n2);
        String keynew = StringOperation.getRef(t1, t2);
        return keynew;
    }

    public String computerD(String n1, String n2) {
        String IDSnew = this.updateIDS(n1, n2);
        String Keynew = this.updateKey(n1, n2);
        String t1 = StringOperation.getRotLeft(IDSnew, Keynew);
        String t2 = StringOperation.binaryStringXOR(n1, n2);
        String t3 = StringOperation.getRef(t1, t2);
        String t4 = StringOperation.getRotRight(t3, n2);
        String D = StringOperation.binaryStringXOR(t4, this.getID());
        this.setIDSnew(IDSnew);
        this.setKeynew(Keynew);
        return D;
    }
}

class StringOperation {

    public static String generateRandomBinaryString(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(2));
        }
        return sb.toString();
    }

    public static String binaryStringXOR(String x, String y) {
        StringBuilder sb = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) != y.charAt(i)) {
                sb.append("1");
            } else sb.append("0");
        }
        return sb.toString();
    }

    public static int getHammingWeight(String x) {
        int n = 0;
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '1') n++;
        }
        return n;
    }

    public static String getRotLeft(String x, String y) {
        int n = getHammingWeight(y);
        String part1 = x.substring(0, n);
        String part2 = x.substring(n);
        return part2 + part1;
    }


    public static String getRotRight(String x, String y) {
        int n = getHammingWeight(y);
        String part1 = x.substring(x.length() - n, x.length());
        String part2 = x.substring(0, x.length() - n);
        return part1 + part2;
    }

    public static String getRef(String x, String y) {
        StringBuilder z = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '1' && y.charAt(i) == '0') {
                z.append(x.charAt((i + 1) % x.length()));
            }
            if (x.charAt(i) == y.charAt(i)) {
                z.append('0');
            }
            if (x.charAt(i) == '0' && y.charAt(i) == '1') {
                z.append(y.charAt((i + 1) % y.length()));
            }
        }
        return z.toString();
    }
}

