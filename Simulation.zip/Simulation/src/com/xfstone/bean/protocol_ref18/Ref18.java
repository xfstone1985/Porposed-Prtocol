package com.xfstone.bean.protocol_ref18;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Random;

public class Ref18 {
    public static String protocolExecution(int taskId, int bitLength){
        StringBuilder sb=new StringBuilder();
        sb.append("-----initial stage begins-----"+"\n");
        Tag tag = new Tag();
        String idold= StringOperation.generateRandomBinaryString(bitLength);
        String keyold=StringOperation.generateRandomBinaryString(bitLength);
        tag.setIDold(idold);
        tag.setKeyold(keyold);
        Reader reader=new Reader();
        reader.setIDold(idold);
        reader.setKeyold(keyold);
        Key key= DESOperation.generateMasterKey();
        reader.setMasterKey(key);
        Server server=new Server();
        server.setMasterKey(key);
        server.setIDold(idold);
        server.setKeyold(keyold);
        sb.append("initial stage ends:"+"\n");
        sb.append("protocol begins to execute:"+"\n");
        String r1=reader.generateR1(bitLength);
        String r2=tag.generateR2(bitLength);
        tag.setR1(r1);
        tag.setR2(r2);
        reader.setR1(r1);
        reader.setR2(r2);
        String hid=tag.computerHID(tag.getIDold(),tag.getR1());
        String m1=tag.computerM1(tag.getIDold(),tag.getR2());
        String m2=tag.computerM2(tag.getIDold(),tag.getKeyold(),tag.getR1(),tag.getR2());
        reader.setM1(m1);
        reader.setM2(m2);
        try {
            String emk=server.computerEMK(server.getIDold(),server.getKeyold());
            if(!reader.checkM2(emk,reader.getM1(), reader.getR1())){
                sb.append("-----M2 is not verified, protocol aborts-----"+"\n");
            }else{
                HashOperation.computerHash(reader.getIDnew());
                DESOperation.encrypt(StringOperation.concatenation(reader.getIDnew(),reader.getKeynew()),reader.getMasterKey());
                server.setIDnew(server.updateID(server.getIDold()));
                server.updateKey(server.getIDnew(), server.getKeyold());
                server.write();
                String m4=reader.computerM4();
                boolean flag=tag.checkM4(m4,tag.updateKey(tag.updateID(tag.getIDold()),tag.getKeyold()),tag.getR1(),tag.getR2());
                if(flag){
                    sb.append("protocol succeeds"+"\n");
                }else sb.append("protocol fails"+"\n");
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        String result="tag["+taskId+"]"+sb;
        return result;
    }
}

class Reader {
    private String keyold;
    private String keynew;
    private String IDold;
    private String IDnew;
    private String r1;
    private String r2;
    private Key masterKey;
    private String m1;
    private String m2;
    public String getM1() {
        return m1;
    }

    public void setM1(String m1) {
        this.m1 = m1;
    }

    public String getM2() {
        return m2;
    }

    public void setM2(String m2) {
        this.m2 = m2;
    }


    public String getIDnew() {
        return IDnew;
    }

    public void setIDnew(String IDnew) {
        this.IDnew = IDnew;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public void setMasterKey(Key masterKey) {
        this.masterKey = masterKey;
    }

    public String getIDold() {
        return IDold;
    }

    public void setIDold(String IDold) {
        this.IDold = IDold;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }
    public String getR1() {
        return r1;
    }

    public void setR1(String r1) {
        this.r1 = r1;
    }

    public String getR2() {
        return r2;
    }

    public void setR2(String r2) {
        this.r2 = r2;
    }
    public Key getMasterKey() {
        return masterKey;
    }

    public String generateR1(int bitLength) {
        return StringOperation.generateRandomBinaryString(bitLength);
    }


    public boolean checkM2(String emk,String m1,String r1) throws Exception {
        boolean flag=false;
        String decryptedDate= DESOperation.decrypt(emk,this.getMasterKey());
        String id=decryptedDate.substring(0,decryptedDate.length()/2);
        String k=decryptedDate.substring(decryptedDate.length()/2);
        String r2=StringOperation.binaryStringXOR(m1,id);
        String m2_local= HashOperation.computerHash(StringOperation.concatenation(id,k,this.getR1(),r2));
        if(m2_local.equals(this.getM2())){
            flag=true;
            this.setIDnew(updateID(this.getIDold()));
            this.setKeynew(updateKey(this.getIDnew(),this.getKeyold()));
        }
        return flag;
    }

    public String updateID(String IDold){
        return HashOperation.computerHash(IDold);
    }
    public String updateKey(String IDnew,String kold){
        String keynew=HashOperation.computerHash(StringOperation.binaryStringXOR(IDnew,kold));
        return keynew;
    }

    public String computerM4(){
        return HashOperation.computerHash(StringOperation.concatenation(this.getKeynew(),this.getR1(),this.getR2()));
    }

}
class Server {
    private String keyold;
    private String keynew;
    private String IDold;
    private String IDnew;
    private Key masterKey;

    public String getIDnew() {
        return IDnew;
    }

    public void setIDnew(String IDnew) {
        this.IDnew = IDnew;
    }

    public String getIDold() {
        return IDold;
    }

    public void setIDold(String IDold) {
        this.IDold = IDold;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public Key getMasterKey() {
        return masterKey;
    }
    public void setMasterKey(Key masterKey) {
        this.masterKey = masterKey;
    }
    public String computerEMK(String id,String k) throws Exception {

        String emk= DESOperation.encrypt(StringOperation.concatenation(id,k),this.getMasterKey());
        return emk;
    }
    public String updateID(String IDold){
        return HashOperation.computerHash(IDold);
    }
    public String updateKey(String IDnew,String kold){
        String keynew=HashOperation.computerHash(StringOperation.binaryStringXOR(IDnew,kold));
        return keynew;
    }
    public void write() throws Exception {
        String hid=updateID(this.getIDold());
        String hidnew=HashOperation.computerHash(hid);
        this.setIDnew(updateID(this.getIDold()));
        this.setKeynew(updateKey(this.getIDnew(),this.getKeyold()));
        DESOperation.encrypt(StringOperation.concatenation(this.getIDold(),this.getKeyold()),this.getMasterKey());
        DESOperation.encrypt(StringOperation.concatenation(this.getIDnew(),this.getKeynew()),this.getMasterKey());

    }
}

class Tag {

    private String keyold;
    private String keynew;
    private String IDold;
    private String IDnew;
    private String r1;
    private String r2;
    public String getIDnew() {
        return IDnew;
    }

    public void setIDnew(String IDnew) {
        this.IDnew = IDnew;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getIDold() {
        return IDold;
    }

    public void setIDold(String IDold) {
        this.IDold = IDold;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }
    public String getR1() {
        return r1;
    }

    public void setR1(String r1) {
        this.r1 = r1;
    }

    public String getR2() {
        return r2;
    }

    public void setR2(String r2) {
        this.r2 = r2;
    }


    public String generateR2(int bitLength) {
        return StringOperation.generateRandomBinaryString(bitLength);
    }

    public String computerHID(String id,String r1){
        return StringOperation.concatenation(HashOperation.computerHash(id),r1);
    }

    public String computerM1(String id,String r2){
        return StringOperation.binaryStringXOR(id,r2);
    }

    public String computerM2(String id,String k,String r1,String r2 ){
        return HashOperation.computerHash(StringOperation.concatenation(id,k,r1,r2));
    }

    public String updateID(String IDold){
        return HashOperation.computerHash(IDold);
    }
    public String updateKey(String IDnew,String kold){
        String keynew=HashOperation.computerHash(StringOperation.binaryStringXOR(IDnew,kold));
        return keynew;
    }
    public boolean checkM4(String m4,String keynew,String r1,String r2){
        boolean flag = false;
        String m4_local=HashOperation.computerHash(StringOperation.concatenation(keynew,r1,r2));
        if (m4.equals(m4_local)) {
            flag = true;
            this.setIDnew(updateID(this.getIDold()));
            this.setKeynew(updateKey(this.getIDnew(),this.getKeyold()));
        }
        return flag;
    }

}
class DESOperation {
    //private static final byte[] MasterKey=generateMasterKey();
    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static Key generateMasterKey(){
        byte[] keyBytes=null;
        Key key =null;
        try {

            KeyGenerator keyGenerator = KeyGenerator.getInstance("DES");

            SecureRandom secureRandom = new SecureRandom();
            keyGenerator.init(secureRandom);


            key = keyGenerator.generateKey();
            keyBytes = key.getEncoded();


            System.out.println("DES密钥: " + bytesToHex(keyBytes));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return key;
    }

    public static String encrypt(String data,Key deskey) throws Exception{
        Cipher cipher= Cipher.getInstance("DES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE,deskey);
        byte[] encryptedData=cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encryptedData);
    }

    public static String decrypt(String data,Key deskey) throws Exception{
        Cipher cipher= Cipher.getInstance("DES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE,deskey);
        byte[] decryptedData=cipher.doFinal(Base64.getDecoder().decode(data));
        return new String(decryptedData,StandardCharsets.UTF_8);
    }
}
class HashOperation {
    public static String computerHash(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder binaryBuilder = new StringBuilder();
            for (byte b : hash) {
                binaryBuilder.append(String.format("%8s", Integer.toBinaryString(b & 0xFF)).replace(' ', '0'));
            }

            return binaryBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
}
class StringOperation {

    public static String generateRandomBinaryString(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(2));
        }
        return sb.toString();
    }

    public static String binaryStringXOR(String x, String y) {
        StringBuilder sb = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) != y.charAt(i)) {
                sb.append("1");
            } else sb.append("0");
        }
        return sb.toString();
    }


    public static String concatenation(String... Strings){
        StringBuilder sb=new StringBuilder();
        for(String string:Strings){
            sb.append(string);
        }
        return sb.toString();
    }
}

