package com.xfstone.bean.protocol_ref37;

import java.util.Random;
public class Ref37{

    public static String protocolExecution(int taskId, int bitLength){
        StringBuilder sb=new StringBuilder();
        //System.out.println("-----initial stage begins-----");
        sb.append("-----initial stage begins-----"+"\n");
        Tag tag = new Tag();
        String idsold = StringOperation.generateRandomBinaryString(bitLength);
        String k = StringOperation.generateRandomBinaryString(bitLength);
        String tid = StringOperation.generateRandomBinaryString(bitLength);
        tag.setIds(idsold);
        tag.setK(k);
        tag.setTid(tid);
        ReaderAndServer readerandServer = new ReaderAndServer();
        readerandServer.setIDSold(idsold);
        readerandServer.setIDSnew(null);
        readerandServer.setK(k);
        readerandServer.setTid(tid);
        sb.append("-----initial stage ends-----"+"\n");
        sb.append("-----protocol begins to execute-----"+"\n");
        String n1=StringOperation.generateRandomBinaryString(bitLength);
        String n2=StringOperation.generateRandomBinaryString(bitLength);
        tag.setN1(n1);
        tag.setN2(n2);
        String a_tag=tag.computerA(tag.getTid(), tag.getK(), tag.getN1(), tag.getN2());
        String b_tag=tag.computerB(tag.getIds(),tag.getK(),tag.getN1(),tag.getN2());
        readerandServer.setN1(n1);
        readerandServer.setN2(n2);
        String a_server=readerandServer.computerA(readerandServer.getTid(),readerandServer.getK(),readerandServer.getN1(),readerandServer.getN2());
        String b_server=readerandServer.computerB(readerandServer.getIDSold(),readerandServer.getK(),readerandServer.getN1(),readerandServer.getN2());
        if(!(a_server.equals(a_tag)&&(b_server.equals(b_tag)))){
            sb.append("-----A and B are not verified, protocol aborts-----"+"\n");
        }else{
            readerandServer.setIDSnew(readerandServer.compuerIDS(readerandServer.getTid(),readerandServer.getK(),readerandServer.getN1(),readerandServer.getN2()));
            String n3=StringOperation.generateRandomBinaryString(bitLength);
            readerandServer.setN3(n3);
            String c_server=readerandServer.cmputerC(readerandServer.getN1(),readerandServer.getN2(),readerandServer.getTid(),readerandServer.getN3());
            String d_server=readerandServer.computerD(readerandServer.getIDSnew(),readerandServer.getN1(),readerandServer.getN2(),readerandServer.getK(),readerandServer.getN3());
            String n3_tag=tag.computerN3(tag.getN1(),tag.getN2(),tag.getTid(),c_server);
            String ids_tag=tag.compuerIDS(tag.getTid(),tag.getK(),tag.getN1(),tag.getN2());
            if(!tag.checkD(ids_tag,tag.getN1(),tag.getN2(),tag.getK(),n3_tag,d_server)){
                sb.append("-----D is not verified, protocol aborts-----"+"\n");
            }else{
                tag.setIds(ids_tag);
                sb.append("tag["+taskId+"] executes protocol successfully!"+"\n");
            }
        }
        String result="tag["+taskId+"]"+sb;
        return result;
    }
}
class ReaderAndServer {
    private String tid;
    private String k;
    private String IDSold;
    private String IDSnew;
    private String n1;
    private String n2;
    private String n3;

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getIDSold() {
        return IDSold;
    }

    public void setIDSold(String IDSold) {
        this.IDSold = IDSold;
    }

    public String getIDSnew() {
        return IDSnew;
    }

    public void setIDSnew(String IDSnew) {
        this.IDSnew = IDSnew;
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getN3() {
        return n3;
    }

    public void setN3(String n3) {
        this.n3 = n3;
    }

    public String computerA(String tid, String k, String n1, String n2){
        return StringOperation.getRotRight(StringOperation.fh(StringOperation.getRotLeft(tid,k),StringOperation.binaryStringXOR(n1,n2)),n2);
    }

    public String computerB(String ids,String k,String n1,String n2){
        return StringOperation.fh(StringOperation.fh(ids,StringOperation.binaryStringXOR(n1,k)),n2);
    }

    public String compuerIDS(String tid,String k,String n1,String n2){
        return StringOperation.getRotLeft(StringOperation.fh(StringOperation.fh(tid,n1),k),n2);
    }

    public String cmputerC(String n1,String n2,String tid,String n3){
        return StringOperation.binaryStringXOR(StringOperation.fh(StringOperation.fh(n1,n2),tid),n3);
    }
    public String computerD(String ids,String n1,String n2,String k,String n3){
        return StringOperation.fh(StringOperation.getRotLeft(StringOperation.getRotRight(StringOperation.fh(ids,n1),k),n2),n3);
    }
}

 class Tag {

    private String tid;
    private String k;
    private String ids;

    private String n1;

    private String n2;

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getK() {
        return k;
    }

    public void setK(String k) {
        this.k = k;
    }

    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }


    public String computerA(String tid,String k,String n1,String n2){
        return StringOperation.getRotRight(StringOperation.fh(StringOperation.getRotLeft(tid,k),StringOperation.binaryStringXOR(n1,n2)),n2);
    }

    public String computerB(String ids,String k,String n1,String n2){
        return StringOperation.fh(StringOperation.fh(ids,StringOperation.binaryStringXOR(n1,k)),n2);
    }

    public String computerN3(String n1,String n2,String tid,String c){
        return StringOperation.binaryStringXOR(StringOperation.fh(StringOperation.fh(n1,n2),tid),c);
    }

    public String compuerIDS(String tid,String k,String n1,String n2){
        return StringOperation.getRotLeft(StringOperation.fh(StringOperation.fh(tid,n1),k),n2);
    }

    public boolean checkD(String ids,String n1,String n2,String k,String n3,String d){
        boolean flag=false;
        String d_local=StringOperation.fh(StringOperation.getRotLeft(StringOperation.getRotRight(StringOperation.fh(ids,n1),k),n2),n3);
        if(d.equals(d_local)) flag=true;
        return flag;
    }
}

 class StringOperation {

    public static String generateRandomBinaryString(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(2));
        }
        return sb.toString();
    }

    public static String binaryStringXOR(String x, String y) {
        StringBuilder sb = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) != y.charAt(i)) {
                sb.append("1");
            } else sb.append("0");
        }
        return sb.toString();
    }

    public static int getrank(String x) {
        int n = 0;
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '1') n++;
        }
        return n;
    }

    public static int getnullity(String x) {
        return x.length()-getrank(x);
    }


    public static String getRotLeft(String x, String y) {
        int n = getrank(y);
        String part1 = x.substring(0, n);
        String part2 = x.substring(n);
        return part2 + part1;
    }
    public static String getRotLeft(String x,int n) {
        String part1 = x.substring(0, n);
        String part2 = x.substring(n);
        return part2 + part1;
    }


    public static String getRotRight(String x, String y) {
        int n = getrank(y);
        String part1 = x.substring(x.length() - n, x.length());
        String part2 = x.substring(0, x.length() - n);
        return part1 + part2;
    }

    public static String getRotRight(String x,int n) {
        String part1 = x.substring(x.length() - n, x.length());
        String part2 = x.substring(0, x.length() - n);
        return part1 + part2;
    }

    public static String getRef(String x, String y) {
        StringBuilder z = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '1' && y.charAt(i) == '0') {
                z.append(x.charAt((i + 1) % x.length()));
            }
            if (x.charAt(i) == y.charAt(i)) {
                //z.append(x.charAt((i+1)%x.length())==y.charAt((i+1)%x.length())?'0':'1');
                z.append('0');
            }
            if (x.charAt(i) == '0' && y.charAt(i) == '1') {
                z.append(y.charAt((i + 1) % y.length()));
            }
        }
        return z.toString();
    }

    public static String concatenation(String... Strings){
        StringBuilder sb=new StringBuilder();
        for(String string:Strings){
            sb.append(string);
        }
        return sb.toString();
    }

    public static String invertBinaryString(String binary) {
        char[] binaryChars = binary.toCharArray();
        StringBuilder invertedBinaryBuilder = new StringBuilder();
        for (char c : binaryChars) {
            invertedBinaryBuilder.append(c == '0' ? '1' : '0');
        }
        return invertedBinaryBuilder.toString();
    }


    public static String fh(String x,String y){
        String rotlx=getRotLeft(x,getnullity(x));
        String rotry=getRotRight(y,getrank(y));
        String x_apo=invertBinaryString(rotlx);
        String y_apo=invertBinaryString(rotry);
        String x_2apo=concatenation(x_apo.substring(0,x_apo.length()/2),y_apo.substring(0,y_apo.length()/2));
        String y_2apo=concatenation(x_apo.substring(x_apo.length()/2,x_apo.length()),y_apo.substring(y_apo.length()/2,y_apo.length()));
        return binaryStringXOR(getRotRight(x_2apo,getrank(x)),getRotLeft(y_2apo,getnullity(y)));

    }


}
