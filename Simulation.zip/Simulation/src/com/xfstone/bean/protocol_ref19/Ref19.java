package com.xfstone.bean.protocol_ref19;

import java.util.Random;

public class Ref19 {
    public static String protocolExecution(int taskId, int bitLength){
        StringBuilder sb=new StringBuilder();
        sb.append("-----initial stage begins-----"+"\n");
        String tid=StringOperation.generateRandomBinaryString(bitLength);
        String rid=StringOperation.generateRandomBinaryString(bitLength);
        String keyold=StringOperation.generateRandomBinaryString(bitLength);
        Tag tag = new Tag();
        tag.setKeyold(keyold);
        tag.setTid(tid);
        tag.setRid(rid);
        Reader reader=new Reader();
        reader.setKeyold(keyold);
        reader.setRid(rid);
        Server server=new Server();
        server.setRid(rid);
        server.setTid(tid);
        server.setKeyold(keyold);
        server.setIdxold(server.cmoputerIDX(rid,tid,keyold));
        server.setIdcold(server.computerIDC(rid,tid,keyold));
        sb.append("-----initial stage ends-----"+"\n");
        sb.append("protocol begins to execute:"+"\n");
        String nr=StringOperation.generateRandomBinaryString(bitLength);
        tag.setNr(nr);
        reader.setNr(nr);
        server.setNr(nr);
        tag.setMark("00");
        String nt=StringOperation.generateRandomBinaryString(bitLength);
        tag.setNt(nt);
        reader.setNt(nt);
        server.setNt(nt);
        String idxold=tag.computerIDXold(tag.getRid(),tag.getTid(),tag.getKeyold());
        tag.setIdxold(idxold);
        String idcold=server.computerIDC(server.getRid(),server.getTid(),server.getKeyold());
        String ns=StringOperation.generateRandomBinaryString(bitLength);
        server.setNs(ns);
        String m1=server.computerM1(server.getNs(),server.getKeyold());
        String m2=server.computerM2(server.getRid(),server.getTid(),server.getKeyold(),server.getNs());
        String TID=reader.computerTID(idcold,reader.getKeyold(),reader.getRid());
        String Ns=reader.computerNS(m1,reader.getKeyold());
        if(!reader.checkM2(m2,reader.getRid(),TID,reader.getKeyold(),Ns)){
           sb.append("-----M2 is not vertified, protocol aborts-----"+"\n");
        }else{
            reader.setTid(TID);
            reader.setNs(Ns);
            String m3=reader.cmputerM3(reader.getTid(),reader.getNr());
            String m4=reader.cmputerM4(reader.getTid(),reader.getNs());
            tag.setNs(StringOperation.binaryStringXOR(m4,tag.getTid()));
            if(!tag.checkTID(m3,tag.getNr())){
               sb.append("-----TID is not verified, protocol aborts-----"+"\n");
            }else{
                //System.out.println(tag.getNr());
                //System.out.println(tag.getNs());
                //System.out.println(tag.getNt());
                //System.out.println(tag.getKeyold());
                String tagkeynew=tag.computerKeynew(tag.getNr(),tag.getNs(),tag.getNt(),tag.getKeyold());
                tag.setKeynew(tagkeynew);
                String tagidxnew=tag.computerIDXnew(tag.getRid(),tag.getTid(),tag.getKeynew());
                tag.setIdxnew(tagidxnew);
                if(!reader.checkIDXnew(tagidxnew,reader.getNr(),reader.getNs(),reader.getNt(), reader.getKeyold(), reader.getRid(), reader.getTid())){
                   sb.append("-----IDXnew is not verified in reader, protocol aborts-----"+"\n");
                }else{
                    String readerkeynew=reader.computerKeynew(reader.getNr(), reader.getNs(), reader.getNt(), reader.getKeyold());
                    reader.setKeynew(readerkeynew);
                    if(!server.checkIDXnew(tagidxnew, server.getNr(), server.getNs(), server.getNt(), server.getKeyold(), server.getRid(), server.getTid())){
                       sb.append("-----IDXnew is not verified in server, protocol aborts-----"+"\n");
                    }else {
                        String serverkeynew= server.computerKeynew(server.getNr(), server.getNs(), server.getNt(), server.getKeyold());
                        server.setKeynew(serverkeynew);
                        String m5=server.computerM5(server.getKeynew(),server.getNt(),server.getNr());
                        if(!reader.checkKeynew(m5,reader.getNt(),reader.getNr())){
                           sb.append("-----keynew is not verified in reader, protocol aborts-----"+"\n");
                        }else{
                            if(!tag.checkKeynew(m5,tag.getNt(),tag.getNr())){
                               sb.append("-----keynew is not verified in tag, protocol aborts-----"+"\n");
                            }else{
                                tag.setMark("01");
                                String m6=tag.computerM6(tag.getMark(),tag.getNs());
                                if(!server.checkMark(m6,server.getNs())){
                                   sb.append("-----mark is not verified in server, protocol aborts-----"+"\n");
                                }else{
                                    server.setIdxnew(server.cmoputerIDX(server.getRid(),server.getTid(),server.getKeynew()));
                                    server.setIdcnew(server.computerIDC(server.getRid(),server.getTid(),server.getKeynew()));
                                    tag.setMark("10");
                                   sb.append("protocol succeeds!"+"\n");
                                }
                            }

                        }

                    }
                }
            }
        }
        String result="tag["+taskId+"]"+sb;
        return result;
    }
}

class Reader {
    private String keyold;
    private String keynew;
    private String rid;
    private String nt;
    private String nr;
    private String ns;
    private String tid;
    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public String getNr() {
        return nr;
    }

    public void setNr(String nr) {
        this.nr = nr;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String generateNR(int bitLength){
        return StringOperation.generateRandomBinaryString(bitLength);
    }

    public String computerNS(String m1,String keyold){
        return StringOperation.binaryStringXOR(m1,keyold);
    }

    //IDC=Rot(Ki ⊕ TID, Ki ⊕ RID)
    public String computerTID(String IDC,String keyold,String rid){
        String hw=StringOperation.binaryStringXOR(keyold,rid);
        String temp=StringOperation.getRotRight(IDC,hw);
        return StringOperation.binaryStringXOR(temp,keyold);
    }

    public boolean checkM2(String m2,String rid,String tid,String keyold,String ns){
        boolean flag=false;
        if(StringOperation.crofunction(StringOperation.binaryStringXOR(rid,tid),StringOperation.binaryStringXOR(keyold,ns)).equals(m2)) flag=true;
        return flag;
    }

    public String cmputerM3(String tid,String nr){
        return StringOperation.binaryStringXOR(tid,nr);
    }

    public String cmputerM4(String tid,String ns){
        return StringOperation.binaryStringXOR(tid,ns);
    }

    public String computerKeynew(String nr,String ns,String nt,String keyold){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(nr,ns),nt),keyold);
    }

    public String computerIDXnew(String rid,String tid,String keynew){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(rid,tid),keynew);
    }

    public boolean checkIDXnew(String idxnew,String nr,String ns,String nt,String keyold,String rid,String tid){
        boolean flag=false;
        String keynew=computerKeynew(nr,ns,nt,keyold);
        String idnew_local=computerIDXnew(rid,tid,keynew);
        if(idxnew.equals(idnew_local)) flag=true;
        return flag;
    }

    public boolean checkKeynew(String m5,String nt,String nr){
        boolean flag=false;
        String keynew_local=StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(nt,m5),nr);
        if(this.getKeynew().equals(keynew_local)) flag=true;
        return flag;
    }
}
class Server {
    private String keyold;
    private String keynew;
    private String rid;
    private String nt;
    private String nr;
    private String ns;
    private String tid;
    private String idxold;
    private String idxnew;
    private String idcold;
    private String idcnew;
    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public String getNr() {
        return nr;
    }

    public void setNr(String nr) {
        this.nr = nr;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getIdcnew() {
        return idcnew;
    }

    public void setIdcnew(String idcnew) {
        this.idcnew = idcnew;
    }

    public String getIdcold() {
        return idcold;
    }

    public void setIdcold(String idcold) {
        this.idcold = idcold;
    }

    public String getIdxnew() {
        return idxnew;
    }

    public void setIdxnew(String idxnew) {
        this.idxnew = idxnew;
    }

    public String getIdxold() {
        return idxold;
    }

    public void setIdxold(String idxold) {
        this.idxold = idxold;
    }

    public String cmoputerIDX(String rid, String tid, String key){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(rid,tid),key);
    }

    public String computerIDC(String rid,String tid,String key){
        return StringOperation.getRotLeft(StringOperation.binaryStringXOR(key,tid),StringOperation.binaryStringXOR(key,rid));
    }

    public String generateNS(int bitLength){
        return StringOperation.generateRandomBinaryString(bitLength);
    }

    public String computerM1(String ns,String keyold){
        return StringOperation.binaryStringXOR(ns,keyold);
    }

    public String computerM2(String rid,String tid,String keyold,String ns){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(rid,tid),StringOperation.binaryStringXOR(keyold,ns));
    }

    public String computerKeynew(String nr,String ns,String nt,String keyold){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(nr,ns),nt),keyold);
    }

    public String computerIDXnew(String rid,String tid,String keynew){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(rid,tid),keynew);
    }

    public boolean checkIDXnew(String idxnew,String nr,String ns,String nt,String keyold,String rid,String tid){
        boolean flag=false;
        String keynew=computerKeynew(nr,ns,nt,keyold);
        String idnew_local=computerIDXnew(rid,tid,keynew);
        if(idxnew.equals(idnew_local)) flag=true;
        return flag;
    }

    public String computerM5(String keynew,String nt,String nr){
        return StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(keynew.substring(0,keynew.length()/2),nt),nr);
    }

    public boolean checkMark(String m6,String ns){
        boolean flag=false;
        if(StringOperation.binaryStringXOR(m6,ns).substring(0,2).equals("01")) flag=true;
        return flag;
    }
}
class Tag {
    private String tid;
    private String rid;
    private String nt;
    private String keyold;
    private String keynew;
    private String idxold;
    private String idxnew;
    private String mark;
    private String nr;
    private String ns;
    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getKeynew() {
        return keynew;
    }

    public void setKeynew(String keynew) {
        this.keynew = keynew;
    }

    public String getKeyold() {
        return keyold;
    }

    public void setKeyold(String keyold) {
        this.keyold = keyold;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getNr() {
        return nr;
    }

    public void setNr(String nr) {
        this.nr = nr;
    }

    public String getNs() {
        return ns;
    }

    public void setNs(String ns) {
        this.ns = ns;
    }

    public String getIdxnew() {
        return idxnew;
    }

    public void setIdxnew(String idxnew) {
        this.idxnew = idxnew;
    }

    public String getIdxold() {
        return idxold;
    }

    public void setIdxold(String idxold) {
        this.idxold = idxold;
    }

    public String generateNT(int bitLength){
        return StringOperation.generateRandomBinaryString(bitLength);
    }

    public String computerIDXold(String rid,String tid,String k){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(rid,tid),k);
    }

    public boolean checkTID(String m3,String nr){
        boolean flag=false;
        String tid_local=StringOperation.binaryStringXOR(m3,nr);
        if(this.getTid().equals(tid_local)) flag=true;
        return flag;
    }

    public String computerKeynew(String nr,String ns,String nt,String keyold){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(nr,ns),nt),keyold);
    }

    public String computerIDXnew(String rid,String tid,String keynew){
        return StringOperation.crofunction(StringOperation.binaryStringXOR(rid,tid),keynew);
    }

    public boolean checkKeynew(String m5,String nt,String nr){
        boolean flag=false;
        String keynew_local=StringOperation.binaryStringXOR(StringOperation.binaryStringXOR(nt,m5),nr);
        if(this.getKeynew().equals(keynew_local)) flag=true;
        return flag;
    }

    public String computerM6(String mark,String ns){
        return StringOperation.binaryStringXOR(mark,ns.substring(0,2));
    }

}
class StringOperation {

    public static String generateRandomBinaryString(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(2));
        }
        return sb.toString();
    }

    public static String binaryStringXOR(String x, String y) {
        StringBuilder sb = new StringBuilder(x.length());
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) != y.charAt(i)) {
                sb.append("1");
            } else sb.append("0");
        }
        return sb.toString();
    }

    public static int getHammingWeight(String x) {
        int n = 0;
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '1') n++;
        }
        return n;
    }

    public static String getRotLeft(String x, String y) {
        int n = getHammingWeight(y);
        String part1 = x.substring(0, n);
        String part2 = x.substring(n);
        return part2 + part1;
    }


    public static String getRotRight(String x, String y) {
        int n = getHammingWeight(y);
        String part1 = x.substring(x.length() - n, x.length());
        String part2 = x.substring(0, x.length() - n);
        return part1 + part2;
    }


    public static String concatenation(String... Strings){
        StringBuilder sb=new StringBuilder();
        for(String string:Strings){
            sb.append(string);
        }
        return sb.toString();
    }

    public static String invertBinaryString(String binary) {
        char[] binaryChars = binary.toCharArray();
        StringBuilder invertedBinaryBuilder = new StringBuilder();
        for (char c : binaryChars) {
            invertedBinaryBuilder.append(c == '0' ? '1' : '0');
        }
        return invertedBinaryBuilder.toString();
    }

    public static String getEvenSubString(String binary){
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<binary.length();i++){
            char c=binary.charAt(i);
            if(i%2==0){
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String getOddSubString(String binary){
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<binary.length();i++){
            char c=binary.charAt(i);
            if(i%2==1){
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String crofunction(String x,String y){
        StringBuilder sb=new StringBuilder();
        String odfnxy=getOddSubString(concatenation(invertBinaryString(x),y));
        String evnyx=getEvenSubString(concatenation(invertBinaryString(y),x));
        String evnxy=getEvenSubString(concatenation(invertBinaryString(x),y));
        String odnyx=getOddSubString(concatenation(invertBinaryString(y),x));
        String oddpart=binaryStringXOR(odfnxy,evnyx);
        String evenpart=binaryStringXOR(evnxy,odnyx);
        for(int i=0;i<x.length();i++){
            StringBuilder temp=new StringBuilder(2);
            temp.append(evenpart.charAt(i)).append(oddpart.charAt(i));
            sb.append(temp);
        }
        return sb.toString();
    }
}

