package com.xfstone.execution;

import com.xfstone.bean.protocol_proposed.ProposedProtocol;
import com.xfstone.bean.protocol_ref18.Ref18;
import com.xfstone.bean.protocol_ref19.Ref19;
import com.xfstone.bean.protocol_ref20.Ref20;
import com.xfstone.bean.protocol_ref22.Ref22;
import com.xfstone.bean.protocol_ref37.Ref37;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class Main {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        int bitLength = 128;
        long startTime = System.nanoTime();
        List<Callable> callableList = new ArrayList<Callable>();
        int n=50;
        for(int i=0;i<n;i++){
            TaskCallable taskCallable=new TaskCallable(i+1,bitLength);
            callableList.add(taskCallable);
        }
        ThreadPoolExecutor executor=new ThreadPoolExecutor(8,16,5,TimeUnit.MILLISECONDS,new LinkedBlockingDeque<Runnable>());
        CompletionService completionService=new ExecutorCompletionService(executor);

        for (int i=0;i<n;i++){
            completionService.submit(callableList.get(i));
        }

        for (int i=0;i<n;i++){
            System.out.println(completionService.take().get());
        }

        Runtime runtime = Runtime.getRuntime();
        // total memory
        long totalMemory = runtime.totalMemory();
        long endTime = System.nanoTime();
        BigDecimal duration = new BigDecimal(endTime - startTime);
        BigDecimal divisor=new BigDecimal(1000000);
        BigDecimal duration_ms=duration.divide(divisor,2,BigDecimal.ROUND_HALF_UP);
        System.out.println("the time for protocol execution is\u0020"+duration_ms.toString() +"\u0020milliseconds");
        long freeMemory = runtime.freeMemory();
        double usedMemory = (totalMemory - freeMemory) / Math.pow(1024, 2);
        System.out.print("the used memory for protocol execution is : ");
        System.out.printf("%.2f MB",usedMemory);

    }



}

class TaskCallable implements Callable<String>{
    private int taskId;
    private int bitLength;


    public TaskCallable(int taskId,int bitLength) {
        this.taskId = taskId;
        this.bitLength = bitLength;
    }



    @Override
    public String call() throws Exception {

        return Ref22.protocolExecution(taskId,bitLength);
    }
}